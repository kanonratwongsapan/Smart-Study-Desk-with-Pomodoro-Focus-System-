// 1. ตั้งค่า Firebase (ใส่ข้อมูลของคุณ)
const firebaseConfig = {
    apiKey: "AIzaSyAZQ015l7sFY1B8dleeZDopb5aPiYdKZZY",
    databaseURL: "https://smartstudydesk-5f37f-default-rtdb.asia-southeast1.firebasedatabase.app"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.database();

// แจ้งสถานะเชื่อมต่อ
const connectedRef = firebase.database().ref(".info/connected");
connectedRef.on("value", (snap) => {
  if (snap.val() === true) {
    document.getElementById("fbStatus").innerText = "OK";
    document.getElementById("fbStatus").style.color = "green";
  } else {
    document.getElementById("fbStatus").innerText = "Disconnected";
    document.getElementById("fbStatus").style.color = "red";
  }
});

// 2. ตั้งค่า Chart.js เบื้องต้น
const lightCtx = document.getElementById('lightChart').getContext('2d');
const distanceCtx = document.getElementById('distanceChart').getContext('2d');

const chartOptions = {
    responsive: true,
    animation: false,
    scales: { x: { display: false }, y: { beginAtZero: true } }
};

const lightChart = new Chart(lightCtx, {
    type: 'line',
    data: { labels: [], datasets: [{ label: 'Light Level', borderColor: '#5897db', data: [], fill: true, backgroundColor: 'rgba(88, 151, 219, 0.2)' }] },
    options: chartOptions
});

const distanceChart = new Chart(distanceCtx, {
    type: 'line',
    data: { labels: [], datasets: [{ label: 'Distance (cm)', borderColor: '#0056b3', data: [], fill: true, backgroundColor: 'rgba(0, 86, 179, 0.2)' }] },
    options: chartOptions
});

function updateChart(chart, value) {
    chart.data.labels.push('');
    chart.data.datasets[0].data.push(value);
    if (chart.data.labels.length > 20) {
        chart.data.labels.shift();
        chart.data.datasets[0].data.shift();
    }
    chart.update();
}

// ฟังก์ชันช่วยเหลือสำหรับสลับสีปุ่ม
function setActiveButton(activeId, inactiveId) {
    document.getElementById(activeId).classList.add('btn-active');
    document.getElementById(inactiveId).classList.remove('btn-active');
}

// 3. ดึงข้อมูลจาก Firebase แบบ Realtime
db.ref('/').on('value', (snapshot) => {
    const data = snapshot.val();
    if(data) {
        // อัปเดตตัวเลข Sensor
        if(data.light !== undefined) {
            document.getElementById('lightValue').innerText = data.light;
            updateChart(lightChart, data.light);
        }
        if(data.distance !== undefined) {
            let dist = data.distance;
            if(dist > 900) dist = "-"; 
            document.getElementById('distanceValue').innerText = dist;
            if(data.distance < 900) updateChart(distanceChart, data.distance);
        }

        // อัปเดตสถานะไฟ LED
        if(data.leds) {
            document.getElementById('ledGreen').innerText = data.leds.green || "OFF";
            document.getElementById('ledYellow').innerText = data.leds.yellow || "OFF";
            document.getElementById('ledRed').innerText = data.leds.red || "OFF";
            document.getElementById('ledFocus').innerText = data.leds.focus || "OFF";
        }

        // อัปเดต Mode และเวลาที่เหลือ (Time Left) รวมถึงสลับสีปุ่มอัตโนมัติ
        if(data.status) {
            const currentMode = data.status.mode || "IDLE";
            document.getElementById('stateStatus').innerText = currentMode;
            document.getElementById('modeDisplay').innerText = currentMode;
            document.getElementById('timeLeft').innerText = data.status.timeLeft || "0";

        }
    }
});

// 4. ปุ่ม Control Panel (ส่งคำสั่งไป Firebase & สลับสีปุ่ม)
document.getElementById('btnLedOn').onclick = () => {
    db.ref('/commands/led').set('ON');
    setActiveButton('btnLedOn', 'btnLedOff');
};
document.getElementById('btnLedOff').onclick = () => {
    db.ref('/commands/led').set('OFF');
    setActiveButton('btnLedOff', 'btnLedOn');
};

document.getElementById('btnBuzzerOn').onclick = () => {
    db.ref('/commands/buzzer').set('ON');
    setActiveButton('btnBuzzerOn', 'btnBuzzerOff');
};
document.getElementById('btnBuzzerOff').onclick = () => {
    db.ref('/commands/buzzer').set('OFF');
    setActiveButton('btnBuzzerOff', 'btnBuzzerOn');
};

document.getElementById('btnStart').onclick = () => {
    db.ref('/commands/state').set('START');
    // สีปุ่ม START/RESET จะถูกอัปเดตอัตโนมัติจากฟังก์ชันดึงข้อมูลด้านบนเมื่อบอร์ดรับคำสั่งสำเร็จ
};
document.getElementById('btnReset').onclick = () => {
    db.ref('/commands/state').set('RESET');
    // สีปุ่ม START/RESET จะถูกอัปเดตอัตโนมัติจากฟังก์ชันดึงข้อมูลด้านบนเมื่อบอร์ดรับคำสั่งสำเร็จ
};