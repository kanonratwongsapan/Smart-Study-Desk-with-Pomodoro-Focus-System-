const express = require('express');
const path = require('path');
const app = express();

const PORT = 3000;

// กำหนดให้เรียกใช้งานไฟล์ (HTML, CSS, JS) ในโฟลเดอร์ public ได้เลย
app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});